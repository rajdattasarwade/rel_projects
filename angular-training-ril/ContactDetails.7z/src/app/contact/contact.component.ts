import { Component, OnInit, Inject } from '@angular/core';
import { SapService } from '../sap.service';
import { DOCUMENT } from "@angular/platform-browser";
import { ToastrService } from 'ngx-toastr';
import { MatDialog, MatDialogRef } from "@angular/material";
import {FormControl, FormGroupDirective, NgForm, Validators,EmailValidator,FormGroup} from '@angular/forms';
import {ErrorStateMatcher} from '@angular/material/core';
import 'rxjs/add/operator/catch'
import { error } from 'util';
import { ngxLoadingAnimationTypes } from 'ngx-loading';

export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }

}

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})

export class ContactComponent implements OnInit {
  matcher = new MyErrorStateMatcher();
  pdfsData
  odata;
  isdcodes;
  url1;
  url2;
  public EmployeeName;
  public LogoUrl;
  public tab: boolean = true;
  public isLoading: boolean = true;
  public disableField: Boolean = true;
  public disableEdit: Boolean = false;
  public disableSave: Boolean = true;
  public show: Boolean = false;
  public show1: Boolean = true;
  public home: Boolean = false;
  public officeno
  oldMobile2: any
  Mobileno2Isd: any
  Mobileno1Isd: any
  OfficenoIsd: any
  ResidencenoIsd:any
  oldOfficePhone: any
  oldResidence: any
  oldpersonalMail: any
  oldOfficeISD: any;
  oldOffice2ISD: any;
  oldResISD: any;
  form = new FormGroup({
    mobileNo1FormControl: new FormControl({value:'',disabled: true}),
    mobileNo2FormControl: new FormControl({value:'',disabled: true}),
    email: new FormControl({ value: '', disabled: true }, [Validators.required, Validators.email]),
    officeemail: new FormControl({ value: '', disabled: true }, [Validators.required, Validators.email]),
    officeNoFormControl: new FormControl({value:'',disabled: true}),
    residentNoFormControl:new FormControl({value:'',disabled: true})
})
  

public loaderColour = '#23297a'
  public config = { 'backdropBorderRadius': '3px',
    'primaryColour':this.loaderColour,
    'secondaryColour':this.loaderColour,
    'tertiaryColour':this.loaderColour }
  showVideoFlag: boolean;
  url: string;
  
  constructor(private sapService: SapService, @Inject(DOCUMENT) private document: any, public dialog: MatDialog, private toastr: ToastrService) { 
    if (!this.odata) {
      this.odata = {};
    }
  }

  ngOnInit() {
    this.getOdata();
    this.getIsd();

  }


  toggle = () => {
    const controls = [this.form.controls['email'],
      this.form.controls['residentNoFormControl'],
      this.form.controls['officeNoFormControl'],
      this.form.controls['mobileNo2FormControl'],
      this.form.controls['mobileNo1FormControl']
    ]
    let i = 0
    while (i <controls.length) {
      if (controls[i].disabled) {
        controls[i].enable();
      } else {
        controls[i].disable();
      }
      i++;
    }
   
 }

  // ONINit Functions


  // getting data from backend on starting
  getOdata() {
    this.sapService.getOdata().then((data) => {
      this.load();
      this.odata = data.d;
    });
  }

  load() {
    this.isLoading = this.sapService.isLoading;
    if (this.isLoading) {
      this.tab = !this.tab;
    }
  }
 

  // Getting isd codes
  getIsd() {
    this.sapService.getIsd().then((data) => {
      this.isdcodes = data.d.results;
    });
  }

  //back button function
  goBack() {
    if(document.referrer.indexOf(window.location.host)!-1&&window.history.length>=2){

      window.history.go(-1)
      }else if(document.referrer.indexOf(window.location.host)!-1&&window.history.length==1){
      //navigate to Launchpad
      location.replace (document.referrer)
      
      }else{
      //navigate to Launchpad
      
      location.replace(window.location.origin+"/sap/bc/ui5_ui5/sap/ZHR_ESSNEW_LP/index.html?")
      
      }
      
  }
  // Save button onClick
  public inputValidatornumeric(event: any) {
    const pattern = /^[0-9]*$/;   
    if (!pattern.test(event.target.value)) {
      event.target.value = event.target.value.replace(/[^0-9]/g, "");

    }
  }
  saveButton(odata) {
    if (isNaN(this.odata.Mobileno1) || (this.odata.Mobileno1.length < 10 && this.odata.Mobileno1.length != 0)) {
      
      this.toastr.error('Mobile Number 1 should be 10 digits', 'Error', { timeOut: 5000, positionClass: 'toast-bottom-center' });
    }
   else if (isNaN(this.odata.Mobileno2) || (this.odata.Mobileno2.length < 10 && this.odata.Mobileno2.length != 0)) {
      
      this.toastr.error('Mobile Number 2 should be 10 digits', 'Error', { timeOut: 5000, positionClass: 'toast-bottom-center' });
    }
    else if (isNaN(this.odata.Officeno) || (this.odata.Officeno.length < 10 && this.odata.Officeno.length != 0)) {
      
      this.toastr.error('Office Number should be 10 digits', 'Error', { timeOut: 5000, positionClass: 'toast-bottom-center' });
    }
    else if (isNaN(this.odata.Residenceno) || (this.odata.Residenceno.length < 10 && this.odata.Residenceno.length != 0)) {
      
      this.toastr.error('Residence Number should be 10 digits', 'Error', { timeOut: 5000, positionClass: 'toast-bottom-center' });
    }
      
    else if (this.form.controls['email'].invalid && this.odata.Personalmail.length>1) {
      
      this.toastr.error('Please fill a valid Personal Email', 'Error', { timeOut: 5000, positionClass: 'toast-bottom-center' });
    }
    else if ((!this.odata.Officeno && this.odata.OfficenoIsd) || (this.odata.Officeno && !this.odata.OfficenoIsd)) {
      this.toastr.error('Please enter valid ISD code for Office Number', 'Error', { timeOut: 5000, positionClass: 'toast-bottom-center' });
    }
    else if ((!this.odata.Residenceno && this.odata.ResidencenoIsd) || (this.odata.Residenceno && !this.odata.ResidencenoIsd)) {
      this.toastr.error('Please enter valid ISD code for Residence Number', 'Error', { timeOut: 5000, positionClass: 'toast-bottom-center' });
    }
    else if ((!this.odata.Mobileno2 && this.odata.Mobileno2Isd) || (this.odata.Mobileno2&& !this.odata.Mobileno2Isd)) {
      this.toastr.error('Please enter valid ISD code for Mobile Number 2', 'Error', { timeOut: 5000, positionClass: 'toast-bottom-center' });
    }
    else if ((!this.odata.Mobileno1 && this.odata.Mobileno1Isd) || (this.odata.Mobileno1&& !this.odata.Mobileno1Isd)) {
      this.toastr.error('Please enter valid ISD code for Mobile Number 1', 'Error', { timeOut: 5000, positionClass: 'toast-bottom-center' });
    }
    
    else {
      
      this.onSubmit(odata)
      
      this.disableField = true;
      this.disableEdit = false;
      this.disableSave = true;
      this.show = !this.show;
      this.show1 = !this.show1;
      this.toggle()

     
     
    }

  }

  onSubmit(odata) {
    this.sapService.getHTTPHeader_self().then((data) => {
      let t = JSON.parse(JSON.stringify(data.headers))
      let lv_token = t["x-csrf-token"][0];
      
      if (lv_token) {
       
        this.isLoading=true
        this.sapService.postContactDet(odata, lv_token).subscribe(
          data => {
            if (odata)
              this.isLoading=false
            this.toastr.success('Successfully Updated', 'Done', { timeOut: 5000, positionClass: 'toast-bottom-center' });
          
            // this.saveButton()
          },
            
          (error) => {
            this.isLoading=false
              let errorMessage = error.error.error.message.value;
              this.errorFunc(errorMessage)
            
                     
          },
          () => {
            this.getOdata();
            
          }
            
          )
        }
      
     
    
  })
}


  // OnClick CancelButton

  cancelButton() {
    this.toggle()
    this.disableField = true;
    this.disableEdit = false;
    this.disableSave = true;
    this.show = !this.show;
    this.show1 = !this.show1;
    this.getOdata();
    
    // this.tab = !this.tab;
    // this.home = !this.home;
  }

  // OnClick Edit Button

  editButton() {
    this.toggle()
    this.disableField = false;
    this.disableEdit = true;
    this.disableSave = false;
    this.show = !this.show;
    this.show1 = !this.show1;
    if(this.odata.Mobileno1==''){this.odata.Mobileno1Isd=this.isdcodes[1].Isd}
    if(this.odata.Mobileno2==''){this.odata.Mobileno2Isd=this.isdcodes[1].Isd}
    if (this.odata.Officeno == '') { this.odata.OfficenoIsd= this.isdcodes[1].Isd }
    if (this.odata.Residenceno == '') { this.odata.ResidencenoIsd = this.isdcodes[1].Isd }
    
    
    // this.tab = !this.tab;
    // this.home = !this.home;
  }

  // onClick Feedback Button

  openUrl() {
    this.url1 = document.location.origin;
    this.url2 = `/sap/bc/ui5_ui5/ui2/ushell/shells/abap/Fiorilaunchpad.html?saml2=disabled&sap-client=186&sap-language=EN#ZHR_ESS-userfeedback?app_id=H0007&app_name=Contact%2520Details`;
    window.open(this.url1 + this.url2);
  }
  errorFunc(value) {
    this.toastr.error(value,'Error',{ timeOut: 5000, positionClass: 'toast-bottom-center' })
  }
 
  openDialog() {
    this.sapService.getGuidelines().subscribe(
      data => {
        this.pdfsData = data.d.results
      
      }
    )
  }
  openPdf(docid, Type, aname) {
        this.showVideoFlag=false
         this.url=``
        if(Type=='V'){
          this.showVideoFlag=true
          this.url = `/sap/opu/odata/sap/ZHR_ESS_CLSTR_DOCUMENTS_SRV/GetDocSet('` + docid + `')/$value`
          
          
        }
        else if(Type=='U'){
         this.sapService.openRTube(aname).subscribe(data=>{
           this.url=data.d.ExUrl
           window.open(this.url,"_blank", "toolbar=no,scrollbars=no,resizable=yes,top=10,left=300,width=800px,height=600px")
          
         })
          
         
        }
        else
        {
          this.url = `/sap/opu/odata/sap/ZHR_ESS_CLSTR_DOCUMENTS_SRV/GetDocSet('` + docid + `')/$value`
          this.showVideoFlag=false
         window.open(this.url)
        }
       
        
  } 
  onCancel() {
    this.showVideoFlag=false
  }
  feedback() {
    window.open(`/sap/bc/ui5_ui5/sap/zhr_ang_feedbck/#/?appName=Contact_Details&appId=H0007`,'_self')
  }
 

}

