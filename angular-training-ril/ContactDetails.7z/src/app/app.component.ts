import { Component, Inject } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { SapService } from './sap.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Contact-Details';

  constructor(@Inject(DOCUMENT) private _document: any, private SapService: SapService, ) { }

  ngOnInit() {
    this.getBU()
  }

  getBU() {
    this.SapService.getempBU().subscribe(
      data => {
        let href1 = "./assets/logo-mini.png"
        let href2 = "./assets/jio-img.png"
        let bgHC = "./assets/hcbackground.gif"
        let bgJio = "./assets/JioBGImage.jpeg"
        if (data.d.Identifier == "true") {
          this._document.getElementById('appFavicon').setAttribute('href', href1);
          this._document.getElementById('body').setAttribute('background', bgHC)
        }
        else {
          this._document.getElementById('appFavicon').setAttribute('href', href2);
          this._document.getElementById('body').setAttribute('background', bgJio)
        }
      }
    )

  }

}


