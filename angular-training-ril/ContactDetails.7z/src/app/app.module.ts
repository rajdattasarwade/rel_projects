import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';
import { AppComponent } from './app.component';
import { ContactComponent } from './contact/contact.component';
import { SapService } from './sap.service';
import { ToastrModule } from 'ngx-toastr';
import {
  MatIconModule, MatTableModule, MatInputModule, MatSelectModule,
  MatOptionModule, MatButtonModule, MatToolbarModule, MatPaginatorModule,
  MatFormFieldModule, MatTooltipModule, MatDialogModule, MatDividerModule
} from '@angular/material';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { NgxLoadingModule } from 'ngx-loading'; 
@NgModule({
  declarations: [
    AppComponent,
    ContactComponent,
  ],

  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpModule,
    ToastrModule.forRoot({
      toastClass: 'toast toast-bootstrap-compatibility-fix'
    }),
    MatIconModule,
    FormsModule,
    MatToolbarModule,
    MatTableModule,
    MatFormFieldModule,
    MatPaginatorModule,
    ReactiveFormsModule,
    MatToolbarModule,
    MatInputModule,
    MatTooltipModule,
    MatDialogModule,
    MatButtonModule,
    HttpClientModule,
    MatSelectModule,
    MatProgressSpinnerModule,
    MatOptionModule,
    MatDividerModule,
     NgxLoadingModule ,
    BrowserAnimationsModule, MatGridListModule],
  entryComponents: [AppComponent],
  providers: [SapService],
  bootstrap: [AppComponent]

})
export class AppModule { }
