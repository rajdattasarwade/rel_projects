import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions } from '@angular/http';
import { HttpHeaders, HttpClient, HttpErrorResponse, HttpHandler,HttpEvent,HttpResponse } from '@angular/common/http';
import { Observable, EMPTY, throwError, of } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
  
export class SapService {
  private url = `/sap/opu/odata/sap/ZHR_ESS_PERSINFO_SRV/EmpContactDetSet(' ')`;
  private posturl = `/sap/opu/odata/sap/ZHR_ESS_PERSINFO_SRV/EmpContactDetSet('')`;
  private isdcode = `/sap/opu/odata/sap/ZHR_ESS_PERSINFO_SRV/EmpIsdcodesSet`;
  private metadataurl = `/sap/opu/odata/sap/ZHR_ESS_PERSINFO_SRV/?$metadata`;
  private getBUurl = `/sap/opu/odata/sap/ZROLE_CHECK_SRV/ES_ROLESet(Role='S:MO_HRESS_HC')`;
  public isLoading:boolean=true;
  constructor(private http: Http, private httpClient: HttpClient) { }
   
  getempBU():Observable<any> {
    return this.httpClient
      .get(this.getBUurl)
  }
  getOdata() {
    this.isLoading=true; 
    return this.http.get(this.url)
      .toPromise()
      .then((response) => {
        this.isLoading=false; 
        return response.json();
      });
  }

  getIsd() {
    return this.http.get(this.isdcode)
      .toPromise()
      .then((response) => {
        return response.json();
      });
  }

  getHTTPHeader_self() {
    let headers = new Headers({ 'Content-Type': 'application/json' });
    headers.append('x-csrf-token', 'fetch');

    let options = new RequestOptions({
      headers: headers,
      method: 'GET'
    });

    return this.http.get(this.metadataurl, options).toPromise()
      .then((response) => {
        // console.log("HTTP GET",response)
        return response;
      });
  }


  postContactDet(is_data, iv_token): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'x-csrf-token': iv_token
      })
    };
  
    return this.httpClient.put(this.posturl, is_data, httpOptions);
  }
  openRTube(aname):Observable<any>{
      return this.httpClient.get(`/sap/opu/odata/sap/ZHR_ESS_CLSTR_DOCUMENTS_SRV/GetRtubeSet(ImAppid='H0007',ImAppsrno='`+aname+`')?`)
    }

  getGuidelines():Observable<any> {
    return this.httpClient
      .get(
        "/sap/opu/odata/sap/ZHR_ESS_CLSTR_DOCUMENTS_SRV/DocListSet?$filter=AppID%20eq%20%27H0007%27"
      )
  }
  

}
